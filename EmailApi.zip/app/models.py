from django.db import models

# Create your models here.
class Email(models.Model):
    subject=models.CharField(max_length=400)
    sender=models.CharField(max_length=600)
    msg=models.TextField()
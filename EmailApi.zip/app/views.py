from django.shortcuts import render
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import os.path
import base64
from bs4 import BeautifulSoup
from .models import Email
from rest_framework import viewsets
from .serializers import EmailSerializer

# Define the SCOPES. If modifying it, delete the token.pickle file.
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']


# Create your views here.

class EmailViewSet(viewsets.ModelViewSet):
    queryset = Email.objects.all()
    serializer_class = EmailSerializer

def index(request):

    # The file token.pickle contains the user access token.
    # Check if it exists
    if os.path.exists('token.pickle'):
        # Read the token from the file and store it in the variable creds
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # If credentials are not available or are invalid, ask the user to log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        # Save the access token in token.pickle file for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    # Connect to the Gmail API
    service = build('gmail', 'v1', credentials=creds)

    # request a list of all the messages
    result = service.users().messages().list(userId='me').execute()

    # We can also pass maxResults to get any number of emails. Like this:
    # result = service.users().messages().list(maxResults=200, userId='me').execute()
    messages = result.get('messages')
    # print(messages)

    # messages is a list of dictionaries where each dictionary contains a message id.

    # iterate through all the messages
    num = 4
    sub = []
    msg1 = []
    fr = []
    for msg in messages:
        # Get the message from its id
        for i in range(num):
            txt = service.users().messages().get(userId='me', id=msg['id']).execute()
            # print(txt['snippet'])
            payload = txt['payload']
            # print(payload)
            headers = payload['headers']
            # print(headers)
            for d in headers:
                if d['name'] == 'Subject':
                    subject = d['value']
                    print("Subject: ", subject)
                    sub.append(subject)
                if d['name'] == 'From':
                    sender = d['value']
                    parts = payload.get('parts')[0]
                    data = parts['body']['data']
                    data = data.replace("-", "+").replace("_", "/")
                    decoded_data = base64.b64decode(data)
                    soup = BeautifulSoup(decoded_data, "lxml")
                    body = soup.body()

                    print("From: ", sender)
                    print("Message: ", body)
                    print('\n')
                    print('*' * 1000)
                    # sub.append(subject)
                    msg1.append(sender)
                    fr.append(body)
        break
    mail=Email(subject=sub,sender=msg1,msg=fr)
    mail.save()
    dest=Email.objects.all()
    return render(request, 'index.html',{'dest':dest})

# class Emaillist(APIView):
#     def get(self,request):
#         email1=Email.objects.all()
#         serializer=EmailSerializer(Email,many=True)
#         return Response(serializer.data)
#     def post(self):
#         pass
